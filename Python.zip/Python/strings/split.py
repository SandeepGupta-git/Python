
str = 'hello to the people of japan'
itm = str.split() #['hello', 'to', 'the', 'people', 'of', 'japan']
print(itm)
print(itm[3]) #people


str2 = 'hello_to_the_people_of_japan'
itm2 = str2.split('_') #['hello', 'to', 'the', 'people', 'of', 'japan']
print(itm2)
print(itm2[2]) #the

