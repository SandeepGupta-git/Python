
fruit = 'banana'
count =0
for itm in fruit:
 if itm == 'a':
    count = count + 1
print(count) #3
