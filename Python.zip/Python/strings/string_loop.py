fruit = 'banana' # ['b','a','n','a','n','a']

for index in fruit:
    print(index)
    #output
    #b
    #a
    #n
    #a
    #n
    #a


index =0
while index < len(fruit):
    print(fruit[index]) 
    index = index+1
    #output
    #b
    #a
    #n
    #a
    #n
    #a
    
