fruit = "this yellow mango"
taste = "is very delicious"

print (fruit + ' ' + taste)

