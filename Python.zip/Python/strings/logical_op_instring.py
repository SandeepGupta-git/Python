
fruit = "this is a avaibility list - banana, mango, Grapes"
if 'grapes' in fruit:
    print('fount capitalize', True)
elif 'Grapes' in fruit:
    print('fount capitalize', True)
else:
    print(False)
    