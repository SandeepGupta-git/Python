_enterName = input('Pls Enetr Your Name =')
_msg = 'Welcome Mr/Mrs ' + _enterName
print(_msg)
