num1 = 5
num2 = 55

if(num1 > num2) :
    print(num1, 'you are greater')
else :
    print(num2 , 'you are greater')
print('End!!')