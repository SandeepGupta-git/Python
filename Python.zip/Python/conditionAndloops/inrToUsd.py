_urInrAmt = input('Enter Price in Rupee')
_cnvtr = int(_urInrAmt) / 90 # current usd = 90 inr
print(_cnvtr)