
x=5
def numCheck():
    x=10
    while x > 0:
        print(x)
        x = x-1
        if x == 4:
            break
numCheck()

n = 0
while True:
    if n == 3:
        break
    print(n)
    n = n + 1