num1 = 110
if(num1 > 10) :
    print('big')
else :
    print('small')
for i in range(10) :
    print('i is-', i)
    if(i>=5):
        print('i is bigger than 5-', i)
        if(i == 5) :
            print('i is exact 5-',i)
    else :
        print('i is lesser than 5-',i)
print('All Done')
