
openFile = open('email.txt')
print(openFile)

abc = 'hello \n world' 
print(abc) # hello
            # world