num1 = input('Enetr no1-')
num2 = input('Enter no2-')


if(num1 > num2) :
    print(num1, 'is big and diff =', float(num1) - float(num2))
elif(num1 == num2):
    print(num1, 'is equal to', num2)
else :
    print(num2, 'is big and diff =', float(num2) - float(num1))
print('End')
