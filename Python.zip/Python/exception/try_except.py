msg1 = '123WWW'

try :
 printMsg1 = int(msg1) # checking for number value if found in strings
 print('first', printMsg1)

except :
    printMsg2 = (msg1)
    print('second', msg1)
print(msg1)
