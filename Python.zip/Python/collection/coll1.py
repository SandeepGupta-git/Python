
fruits = ['Mango','banana']

for fruitNames in fruits:
    print(fruitNames)