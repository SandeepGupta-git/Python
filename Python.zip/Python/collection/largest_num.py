
largest_num = 0

for num in [2,22,4,11,44,33] :
    if num > largest_num :
        largest_num = num
        print(largest_num)
print('largest', largest_num)
