
list = [1,'Mon','coffee']
if 1 in list:
    print(True) 
print(list) 