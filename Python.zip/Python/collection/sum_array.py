
start = 0
for i in [2,33,21,1,44] :
    start = start + i
    print(start)
print('sum =', start)