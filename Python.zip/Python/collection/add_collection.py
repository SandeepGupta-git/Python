arr1 = [1,2,3,4]

arr2 = [5,6,7]

allitems= arr1 + arr2

print(allitems)