
list = [1,'Mon','coffee']

newList = list.append('tea')
print(list) # [1, 'Mon', 'coffee', 'tea']
print(newList) # none

